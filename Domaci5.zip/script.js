//

function promenaBoje() {
	document.getElementById("promena").style.color = "royalblue";
}
document.getElementById("promena").addEventListener("click", promenaBoje);

//

function promenaFonta() {
	document.getElementById("fontSize").style.fontSize = "6rem";
}
document.getElementById("fontSize").addEventListener("click", promenaFonta);
